import pandas as pd
from matplotlib import pyplot as plt


plt.style.use('bmh')
data = pd.read_csv("C:\\Users\\Lenovo\\Desktop\\Municipal 2011.csv",encoding='latin1')
print(data.head())
x = data['Country']
y = data['Total population served by municipal waste collection(%)']

# Bar chart
#plt.title('Total population served by municipal waste collection')
#UN = ['Albania', 'Algeria', 'Andorra', 'Angola', 'Anguilla', 'Antigua and Barbuda', 'Argentina', 'Armenia','Australia','Austria','Azerbaijan','Bahamas','Belarus','Belgium','Belize','Benin','Bolivia','Bosnia and Herzegovina','Brazil','British Virgin Islands','Brunei Darussalam','Bulgaria','Burkina Faso','Cameroon','Canada','Chile','China','China, Hong Kong SAR','China, Macao SAR','Colombia','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Denmark','Dominica','Dominican Republic','Ecuador','Egypt','El Salvador','Estonia','Finland','France','French Guiana','Georgia','Germany','Greece','Guadeloupe','Guatemala','Hungary','Iceland','India','Indonesia','Iraq','Ireland','Israel','Italy','Jamaica','Japan','Jordan','Kazakhstan','Kenya','Korea','Kuwait','Kyrgyzstan','Latvia','Lebanon','Lithuania','Luxembourg','Madagascar','Maldives','Malta','Marshall Islands','Martinique','Mauritius','Mexico','Monaco','Montenegro','Morocco','Nepal','Netherlands','New Zealand','Niger','Norway','Occupied Palestinian Territory','Panama','Paraguay','Peru','Philippines','Poland','Portugal','Qatar','Republic of Moldova','Réunion','Romania','Russian Federation','Senegal','Serbia','Singapore','Slovakia','Slovenia','Spain','Sri Lanka','St. Vincent and the Grenadines','Sudan','Suriname','Sweden','Switzerland','Syrian Arab Republic','Thailand','The Former Yugoslav Rep. of  Macedonia','Trinidad and Tobago','Tunisia','Turkey','Uganda','Ukraine','United Arab Emirates','United Kingdom','United States','Uruguay','Yemen','Zambia']
#x_pos = range(len(UN))
#plt.xticks(x_pos, UN, rotation = 90, fontsize=6)
#plt.xlabel('Country', fontsize=14)
#Percentage = [85.0, 80.0, 100.0,79.6,100.0,95.0,88.3,72.1,82.0,100.0,61.9,16.6,100.0,100.0,51.4,77.2,49.0,67.0,86.6,97.2,36.4,96.7,9.1,61.6,99.0,44.2,82.3,100.0,100.0,18.6,73.0,93.0,75.4,100.0,100.0,100.0,94.0,59.5,49.0,90.2,53.0,79.0,100.0,100.0,100.0,60.0,100.0,100.0,100.0,22.2,92.5,100.0,63.3,52.1,55.6,76.0,89.6,100.0,76.0,99.8,77.8,67.3,40.0,99.3,100.0,56.7,85.0,77.1,91.0,100.0,17.7,72.8,100.0,60.0,100.0,98.0,90.0,100.0,22.3,15.7,60.4,100.0,87.9,58.2,99.0,75.1,64.2,37.6,75.0,70.0,79.1,100.0,92.7,67.8,100.0,54.0,92.3,21.4,72.4,100.0,100.0,94.5,100.0,55.8,100.0,65.4,67.0,100.0,99.0,74.0,81.3,72.0,90.0,77.4,82.0,32.6,21.9,54.7,100.0,100.0,78.4,19.2,20.0,]
#y_pos = range(len(Percentage))
#plt.yticks(y_pos, Percentage, fontsize = 5)
#plt.ylabel('Total population served by municipal waste collection(%)', fontsize=14)
#plt.bar(x, y)

# Histogram
#Percentage = [85.0, 80.0, 100.0,79.6,100.0,95.0,88.3,72.1,82.0,100.0,61.9,16.6,100.0,100.0,51.4,77.2,49.0,67.0,86.6,97.2,36.4,96.7,9.1,61.6,99.0,44.2,82.3,100.0,100.0,18.6,73.0,93.0,75.4,100.0,100.0,100.0,94.0,59.5,49.0,90.2,53.0,79.0,100.0,100.0,100.0,60.0,100.0,100.0,100.0,22.2,92.5,100.0,63.3,52.1,55.6,76.0,89.6,100.0,76.0,99.8,77.8,67.3,40.0,99.3,100.0,56.7,85.0,77.1,91.0,100.0,17.7,72.8,100.0,60.0,100.0,98.0,90.0,100.0,22.3,15.7,60.4,100.0,87.9,58.2,99.0,75.1,64.2,37.6,75.0,70.0,79.1,100.0,92.7,67.8,100.0,54.0,92.3,21.4,72.4,100.0,100.0,94.5,100.0,55.8,100.0,65.4,67.0,100.0,99.0,74.0,81.3,72.0,90.0,77.4,82.0,32.6,21.9,54.7,100.0,100.0,78.4,19.2,20.0,]
#plt.xlabel('Country', fontsize=10)
#plt.ylabel('Total population served by municipal waste collection(%)', fontsize=10)
#plt.hist([Percentage, UN], bins = [20,40,60,80,100], label=['Percentage','UN'], rwidth = 0.9,orientation='horizontal')
#plt.legend()


# Pie chart
#plt.title('Total population served by municipal waste collection')
#Percentage = [85.0, 80.0, 100.0,79.6,100.0,95.0,88.3,72.1,82.0,100.0,61.9,16.6,100.0,100.0,51.4,77.2,49.0,67.0,86.6,97.2,36.4,96.7,9.1,61.6,99.0,44.2,82.3,100.0,100.0,18.6,73.0,93.0,75.4,100.0,100.0,100.0,94.0,59.5,49.0,90.2,53.0,79.0,100.0,100.0,100.0,60.0,100.0,100.0,100.0,22.2,92.5,100.0,63.3,52.1,55.6,76.0,89.6,100.0,76.0,99.8,77.8,67.3,40.0,99.3,100.0,56.7,85.0,77.1,91.0,100.0,17.7,72.8,100.0,60.0,100.0,98.0,90.0,100.0,22.3,15.7,60.4,100.0,87.9,58.2,99.0,75.1,64.2,37.6,75.0,70.0,79.1,100.0,92.7,67.8,100.0,54.0,92.3,21.4,72.4,100.0,100.0,94.5,100.0,55.8,100.0,65.4,67.0,100.0,99.0,74.0,81.3,72.0,90.0,77.4,82.0,32.6,21.9,54.7,100.0,100.0,78.4,19.2,20.0,]
#labels= ['Albania', 'Algeria', 'Andorra', 'Angola', 'Anguilla', 'Antigua and Barbuda', 'Argentina', 'Armenia','Australia','Austria','Azerbaijan','Bahamas','Belarus','Belgium','Belize','Benin','Bolivia','Bosnia and Herzegovina','Brazil','British Virgin Islands','Brunei Darussalam','Bulgaria','Burkina Faso','Cameroon','Canada','Chile','China','China, Hong Kong SAR','China, Macao SAR','Colombia','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Denmark','Dominica','Dominican Republic','Ecuador','Egypt','El Salvador','Estonia','Finland','France','French Guiana','Georgia','Germany','Greece','Guadeloupe','Guatemala','Hungary','Iceland','India','Indonesia','Iraq','Ireland','Israel','Italy','Jamaica','Japan','Jordan','Kazakhstan','Kenya','Korea','Kuwait','Kyrgyzstan','Latvia','Lebanon','Lithuania','Luxembourg','Madagascar','Maldives','Malta','Marshall Islands','Martinique','Mauritius','Mexico','Monaco','Montenegro','Morocco','Nepal','Netherlands','New Zealand','Niger','Norway','Occupied Palestinian Territory','Panama','Paraguay','Peru','Philippines','Poland','Portugal','Qatar','Republic of Moldova','Réunion','Romania','Russian Federation','Senegal','Serbia','Singapore','Slovakia','Slovenia','Spain','Sri Lanka','St. Vincent and the Grenadines','Sudan','Suriname','Sweden','Switzerland','Syrian Arab Republic','Thailand','The Former Yugoslav Rep. of  Macedonia','Trinidad and Tobago','Tunisia','Turkey','Uganda','Ukraine','United Arab Emirates','United Kingdom','United States','Uruguay','Yemen','Zambia']
#plt.pie(Percentage, labels=labels, autopct='%1.1f%%')
#plt.legend()

# Pie chart
# Standard deviation = 25.35943203
# Interquartile range = 39
# African average = 55 
#labels= ['Standard deviation', 'Interquartile range', 'African average']
#Num = [25.35943203, 39, 55]
#plt.pie(x=Num, labels=labels, autopct='%1.1f%%')


plt.tight_layout()

plt.show()

#NB: To view the chart/graph delete the # before the code in and then run the code.
#Errors will occur if you try to run more than one chart/graph at the same time.


#Short note on the assignment
#Topic: Total population served by municipal waste collection (2011-2019)
#The latest information about this topic that I could find was last updated on March,2011.

# Municipal waste, collected by or on behalf of municipalities, by public or private enterprises,
#includes waste originating from: households, commerce and trade, small businesses, office buildings
#and institutions (schools, hospitals, government buildings). It also includes bulky waste
#(e.g., white goods, old furniture, mattresses) and waste from selected municipal services,
#e.g., waste from park and garden maintenance, waste from street cleaning services 
#(street sweepings, the content of litter containers, market cleansing waste), 
#if managed as waste. The definition excludes waste from municipal sewage network and treatment,
#municipal construction and demolition waste.

#Municipal waste collected refers to waste collected by or on behalf of municipalities, as well as 
#municipal waste collected by the private sector. It includes mixed waste, and fractions collected 
#separately for recovery operations (through door-to-door collection and/or through voluntary deposits).
#Total population served by municipal waste collection is the proportion of the total population covered 
#by regular municipal waste removal service in relation to the total population of the country.

#For non-EU countries, municipal waste collected per capita served is calculated by UNSD by dividing the
#municipal waste collected by the number of people served by the waste collection system. For EU countries,
#data for municipal waste collected per capita are from Eurostat Environmental Data Center on Waste.